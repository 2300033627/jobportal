package klu.model;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class User {
	String fullname;
	@Id
	String email;
	String password;
	int role;
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "User [fullname=" + fullname + ", email=" + email + ", password=" + password + ", role=" + role + "]";
	}
	
	
}
