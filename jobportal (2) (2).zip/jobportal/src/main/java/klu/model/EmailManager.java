package klu.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailManager {
	
	@Autowired
	JavaMailSender JMS;
	
	public String sendMail(String tomail,String sub,String msg)
	{
		try {
		SimpleMailMessage SMS=new SimpleMailMessage();
		SMS.setFrom("mailtoblnp@gmail.com");
		SMS.setTo(tomail);
		SMS.setSubject(sub);
		SMS.setText(msg);
		JMS.send(SMS);
		return "200::Mail Sent Successfully";
		}
		catch(Exception e)
		{
			return "401::Error"+e.getMessage();
		}
	}
}
