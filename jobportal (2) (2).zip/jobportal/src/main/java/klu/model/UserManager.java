package klu.model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import klu.repository.UserRepository;
@Service
public class UserManager {
	@Autowired	
	UserRepository UR;
	
	@Autowired
	EmailManager EM;
	
	@Autowired
	JWTManager JWT;
	public String insertData(User u)
	{	
		if(UR.validateEmail(u.getEmail())>0)
			return "401::Email already exists";
		
		UR.save(u);
		return "200::Data inserted";
	}
	public String retrievePassword(String email)
	{
		User u=UR.findById(email).get();
		String to=u.getEmail();
		String sub="Password Recovery from DB";
		String message= "Dear user "+u.getFullname()+", "+"your password is "+u.getPassword();
		
		return EM.sendMail(email, sub, message);
	}
	
	public String validateCredentials(String email,String password)
	{
		if(UR.validateCredentials(email, password)>0)
		{
			String token=JWT.generateToken(email);
			return "200::"+token;
		}
		return "401::Invalid Credentials";
		
	}
	
	//Fetch user's Fullname from database
		public String getFullName(String token)
		{
			String email = JWT.validateJWT(token);
			if(email.equals("401"))
				return "401::Invalid Token";
			
		    User U = UR.findById(email).orElse(null);
			return  U.getFullname();
		}
}