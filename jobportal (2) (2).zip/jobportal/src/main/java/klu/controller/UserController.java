package klu.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import klu.model.User;
import klu.model.UserManager;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:5173/")
public class UserController {
	@Autowired
	UserManager UM;
	
	@GetMapping("/display")
	public String display() {
		return "Welcome to Spring Boot";
	}
	
	@PostMapping("/save")
	public String insertRecordIntoDb(@RequestBody User u)
	{
		 return UM.insertData(u);
		//return "data inserted";
	}
	@PostMapping("/forget")
	public String forgetPassword(@RequestBody User u)
	{
		return UM.retrievePassword(u.getEmail());
	}
	@PostMapping("/signin")
	public String signin(@RequestBody User u)
	{
		return UM.validateCredentials(u.getEmail(),u.getPassword());
	}
	@PostMapping("/getfullname")
	public String getFullName(@RequestBody Map<String, String> data)
	{
		return UM.getFullName(data.get("csrid"));
	}



}
